// Main JavaScript File for application

