package org.gatechproject.project4.BAL.dto;

import org.gatechprojects.project4.SharedDataModules.User;

public class TeacherAssistant extends Person {

	public TeacherAssistant() {
	}

	public TeacherAssistant(User user) {
		super(user);
	}

}
