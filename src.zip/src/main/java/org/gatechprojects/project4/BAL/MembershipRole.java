package org.gatechprojects.project4.BAL;

public enum MembershipRole {
	PROFESSOR, TA, STUDENT
}
