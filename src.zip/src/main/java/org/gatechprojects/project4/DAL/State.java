package org.gatechprojects.project4.DAL;

public enum State {
	LATENT, INITIALIZED, CLOSED
}
